import socket
import struct
import os
import binascii

def create_sniffer():
    if os.name == 'nt':
        # Windows raw socket
        sniffer = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_IP)
        sniffer.bind((socket.gethostbyname(socket.gethostname()), 0))
        sniffer.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
        sniffer.ioctl(socket.SIO_RCVALL, socket.RCVALL_ON)
    else:
        # Linux/Unix raw socket
        sniffer = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))
    return sniffer

def ethernet_frame(data):
    dest_mac, src_mac, proto = struct.unpack('!6s6sH', data[:14])
    return binascii.hexlify(src_mac, ':').decode(), binascii.hexlify(dest_mac, ':').decode(), socket.htons(proto), data[14:]

def ipv4_packet(data):
    version_header_len = data[0]
    header_len = (version_header_len & 15) * 4
    ttl, proto, src, dest = struct.unpack('!8xBB2x4s4s', data[:20])
    src_ip = socket.inet_ntoa(src)
    dest_ip = socket.inet_ntoa(dest)
    return ttl, proto, src_ip, dest_ip, data[header_len:]

def icmp_packet(data):
    type, code = struct.unpack('!BB', data[:2])
    return type, code, data[4:8], data[8:]

def tcp_segment(data):
    src_port, dest_port, seq, ack, offset_reserved_flags = struct.unpack('!HHLLH', data[:14])
    offset = (offset_reserved_flags >> 12) * 4
    flags = offset_reserved_flags & 0x3F  # Simplified flags
    return src_port, dest_port, flags, data[offset:]

def udp_segment(data):
    src_port, dest_port, size = struct.unpack('!HHH', data[:6])
    return src_port, dest_port, size, data[8:]

def main():
    try:
        sniffer = create_sniffer()
    except PermissionError:
        print("Error: Administrative privileges required to run sniffer.")
        return

    print("Basic Network Sniffer Running...")
    print("Source IP -> Dest IP | Protocol | Ports/Payload Info\n")

    try:
        while True:
            raw_data, _ = sniffer.recvfrom(65565)
            eth_proto = 8  # Default to IPv4 for Windows

            if os.name != 'nt':
                src_mac, dest_mac, eth_proto, data = ethernet_frame(raw_data)
                print(f"MAC: {src_mac} -> {dest_mac}")

            if eth_proto == 8 or os.name == 'nt':
                try:
                    ttl, proto, src_ip, dest_ip, data = ipv4_packet(data if os.name != 'nt' else raw_data)
                    print(f"{src_ip} -> {dest_ip} | TTL: {ttl} | ", end='')

                    if proto == 1:
                        type, code, _, payload = icmp_packet(data)
                        print(f"ICMP Type: {type} Code: {code}")
                        if len(payload) > 0:
                            print(f"Payload: {binascii.hexlify(payload[:32]).decode()}...")

                    elif proto == 6:
                        src_port, dest_port, flags, payload = tcp_segment(data)
                        print(f"TCP {src_port} -> {dest_port} Flags: {flags}")
                        if len(payload) > 0:
                            if dest_port in [80, 443] or src_port in [80, 443]:
                                print(f"Possible HTTP Payload: {binascii.hexlify(payload[:100]).decode()}")

                    elif proto == 17:
                        src_port, dest_port, size, payload = udp_segment(data)
                        print(f"UDP {src_port} -> {dest_port}")
                        if len(payload) > 0:
                            print(f"Payload: {binascii.hexlify(payload[:32]).decode()}...")

                    else:
                        print(f"Other Protocol: {proto}")
                except struct.error:
                    print("Error parsing packet.")

    except KeyboardInterrupt:
        print("\nSniffer stopped.")
        if os.name == 'nt':
            sniffer.ioctl(socket.SIO_RCVALL, socket.RCVALL_OFF)

if __name__ == "__main__":
    main()