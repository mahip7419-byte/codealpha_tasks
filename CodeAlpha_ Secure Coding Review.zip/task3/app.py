from flask import Flask, request
import sqlite3
import bcrypt

app = Flask(__name__)

# Initialize database - store hash as BLOB (bytes) for proper bcrypt handling
def init_db():
    conn = sqlite3.connect('users.db')
    conn.execute("PRAGMA foreign_keys = 1")
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users 
                 (username TEXT UNIQUE, password BLOB)''')  # Changed to BLOB
    
    # Hash password as bytes
    password = 'password123'.encode('utf-8')
    hashed = bcrypt.hashpw(password, bcrypt.gensalt())
    
    # Insert admin user (as bytes)
    try:
        c.execute("INSERT INTO users (username, password) VALUES (?, ?)", 
                  ('admin', hashed))  # hashed is already bytes
    except sqlite3.IntegrityError:
        pass
    
    conn.commit()
    conn.close()

init_db()

@app.route('/login', methods=['GET', 'POST'])
def login():
    message = ''
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password'].encode('utf-8')
        
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute("SELECT password FROM users WHERE username = ?", (username,))
        result = c.fetchone()
        conn.close()
        
        if result and bcrypt.checkpw(password, result[0]):  # result[0] is now bytes!
            message = f"Login successful! Welcome, {username}"
        else:
            message = "Invalid credentials."
    
    return '''
    <h2>Secure Login</h2>
    <form method="post">
        Username: <input type="text" name="username" required><br><br>
        Password: <input type="password" name="password" required><br><br>
        <input type="submit" value="Login">
    </form>
    <p><strong>{}</strong></p>
    '''.format(message)

if __name__ == '__main__':
    app.run(debug=False)